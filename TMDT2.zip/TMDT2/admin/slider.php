<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<section class="admin-content">
        <div class="admin-content-left">
            <ul>
                <li><a href="donhang.php">Đơn hàng</a></li>
                <li><a>Danh mục</a>
                    <ul>
                        <li><a href="cartegoryadd.php">Thêm Danh mục</a></li>
                        <li><a href="cartegorylist.php">Danh sách Danh mục</a></li>
                    </ul>
                </li>
                <li><a>Loại sản phẩm</a>
                    <ul>
                        <li><a href="brandadd.php">Thêm Loại sản phẩm</a></li>
                        <li><a href="brandlist.php">Danh sách Loại sản phẩm</a></li>
                    </ul>
                </li>
                <li><a>Sản phẩm</a>
                    <ul>
                        <li><a href="productadd.php">Thêm Sản phẩm</a></li>
                        <li><a href="productlist.php">Danh sách Sản phẩm</a></li>
                    </ul>
                </li>
                <li><a>Tài khoản</a>
                    <ul>
                        <li><a href="tkadd.php">Thêm Tài khoản</a></li>
                        <li><a href="tklist.php">Danh sách Tài khoản   </a></li>
                    </ul>
                </li>
                <li><a>Khách hàng</a>
                    <ul>
                        <li><a href="guessadd.php">Thêm Khách hàng</a></li>
                        <li><a href="guesslist.php">Danh sách Khách hàng   </a></li>
                    </ul>
                </li>
                <li><a>Khuyến mãi</a>
                    <ul>
                        <li><a href="saleadd.php">Thêm Khuyến mãi</a></li>
                        <li><a href="salelist.php">Danh sách Khuyến mãi</a></li>
                    </ul>
                </li>
                <li><a href="thongke.php">Thống kê</a></li>
                <li><a href="../logout.php">Đăng xuất</a></li>
            </ul>
        </div>